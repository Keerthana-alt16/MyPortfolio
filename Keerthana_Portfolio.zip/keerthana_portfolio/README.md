# Keerthana R — Portfolio

Open `index.html` in a browser to view the portfolio.

To publish it as a public website, upload the folder to GitHub Pages or another static hosting service.
Replace `keerthana@example.com` in `index.html` with the real email address before publishing.
